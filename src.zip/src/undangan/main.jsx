import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import Undangan from "./Undangan.jsx";

createRoot(document.getElementById("root")).render(
<StrictMode>
<Undangan/>
</StrictMode>
)